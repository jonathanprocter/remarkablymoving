import datetime
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape, portrait
from reportlab.lib.units import inch
from reportlab.lib import colors

# reMarkable Pro specifications
REMARKABLE_WIDTH = 1620
REMARKABLE_HEIGHT = 2160

# Define page sizes
landscape_size = (REMARKABLE_HEIGHT, REMARKABLE_WIDTH)
portrait_size = (REMARKABLE_WIDTH, REMARKABLE_HEIGHT)

def create_weekly_view(c, week_start_date):
    c.setPageSize(landscape_size)
    c.setFont("Helvetica", 36)
    c.drawString(inch, landscape_size[1] - inch, f"WEEKLY OVERVIEW - WEEK OF {week_start_date.strftime('%B %d, %Y').upper()}")

    # Draw weekly grid
    days = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"]
    x_start = inch
    y_start = landscape_size[1] - 2 * inch
    col_width = (landscape_size[0] - 2 * inch) / 8
    row_height = (landscape_size[1] - 4 * inch) / 31

    # Draw header
    c.setFont("Helvetica-Bold", 24)
    for i, day in enumerate(days):
        c.drawString(x_start + (i + 1) * col_width + 20, y_start + 10, day)
        # Add links to daily pages
        c.linkRect(day, f"day_{i+1}", (x_start + (i + 1) * col_width, y_start, x_start + (i + 2) * col_width, y_start + row_height))


    # Draw time slots
    c.setFont("Helvetica", 18)
    for i in range(31):
        time = f"{(i // 2) + 7:02d}:{30 * (i % 2):02d}"
        c.drawString(x_start + 10, y_start - i * row_height, time)

    # Draw grid lines
    c.setStrokeColor(colors.black)
    for i in range(8):
        c.line(x_start + i * col_width, y_start + row_height, x_start + i * col_width, y_start - 30 * row_height)
    for i in range(32):
        c.line(x_start, y_start - (i-1) * row_height, x_start + 8 * col_width, y_start - (i-1) * row_height)

    c.showPage()

def create_daily_view(c, date, day_name, page_num):
    c.setPageSize(portrait_size)
    c.setFont("Helvetica", 36)
    c.drawString(inch, portrait_size[1] - inch, f"{day_name.upper()} - {date.strftime('%B %d, %Y')}")

    # Add link back to weekly view
    c.linkURL("#weekly_view", (0, 0, 100, 100), relative=1)

    # Draw daily schedule
    x_start = inch
    y_start = portrait_size[1] - 2 * inch
    row_height = (portrait_size[1] - 4 * inch) / 31

    # Draw time slots
    c.setFont("Helvetica", 18)
    for i in range(31):
        time = f"{(i // 2) + 7:02d}:{30 * (i % 2):02d}"
        c.drawString(x_start + 10, y_start - i * row_height, time)

    # Draw grid lines
    c.setStrokeColor(colors.black)
    c.line(x_start + 1.5*inch, y_start + row_height, x_start + 1.5*inch, y_start - 30 * row_height)
    for i in range(32):
        c.line(x_start, y_start - (i-1) * row_height, portrait_size[0] - inch, y_start - (i-1) * row_height)

    c.showPage()

def generate_calendar_pdf(filename="weekly_calendar.pdf"):
    c = canvas.Canvas(filename)
    c.setAuthor("Manus AI")
    c.setTitle("Weekly Calendar Overview")

    # Get current week's Monday
    today = datetime.date.today()
    week_start_date = today - datetime.timedelta(days=today.weekday())

    # Create weekly view
    c.bookmarkPage("weekly_view")
    c.addOutlineEntry("Weekly Overview", "weekly_view", 0, 0)
    create_weekly_view(c, week_start_date)

    # Create daily views
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    for i, day in enumerate(days):
        date = week_start_date + datetime.timedelta(days=i)
        c.bookmarkPage(f"day_{i+1}")
        c.addOutlineEntry(day, f"day_{i+1}", 1, 0)
        create_daily_view(c, date, day, i + 2)

    c.save()

if __name__ == "__main__":
    generate_calendar_pdf()

