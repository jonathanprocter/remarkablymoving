# reMarkable Pro Calendar PDF Exporter

A comprehensive solution for generating weekly calendar PDFs optimized for the reMarkable Pro device, addressing all the issues identified in your original PDF export.

## Features

✅ **Optimized for reMarkable Pro**
- Landscape weekly overview: 2160x1620 pixels
- Portrait daily views: 1620x2160 pixels
- Perfect fit for 11.8" display with 229 PPI

✅ **Proper Time Format**
- Military time format (07:00-22:00)
- 30-minute intervals throughout the day
- Covers full business hours from 7 AM to 10 PM

✅ **Complete 8-Page Layout**
- Page 1: Landscape weekly overview
- Pages 2-8: Portrait daily views (Monday-Sunday)

✅ **Bidirectional Hyperlinks**
- Click day names in weekly view to jump to daily pages
- "Back to Weekly" links on each daily page
- Seamless navigation between views

✅ **Event Integration**
- Event blocks proportional to duration
- Visual representation in both weekly and daily views
- Support for titles, times, and descriptions

✅ **E-ink Display Optimized**
- High contrast formatting
- Clean, readable typography
- Optimized for reMarkable's e-ink technology

## Quick Start

### Option 1: Standalone Python Script

1. Copy `simple_calendar_generator.py` to your local machine
2. Install required dependencies:
   ```bash
   pip install reportlab
   ```
3. Run the script:
   ```bash
   python simple_calendar_generator.py
   ```

### Option 2: Web Application (Recommended for Replit)

1. Copy the entire `calendar-pdf-exporter` folder to Replit
2. Install dependencies:
   ```bash
   pip install flask flask-cors reportlab
   ```
3. Run the application:
   ```bash
   python src/main.py
   ```
4. Access the web interface at `http://localhost:5000`

## Replit Setup Instructions

### Step 1: Create New Replit Project
1. Go to Replit.com and create a new Python project
2. Name it "remarkable-calendar-exporter"

### Step 2: Upload Files
Copy these files to your Replit project:

**Main Application Files:**
- `src/main.py` - Flask application entry point
- `src/routes/calendar.py` - PDF generation API endpoint
- `src/generate_calendar.py` - Core PDF generation logic
- `src/static/index.html` - Web interface
- `requirements.txt` - Python dependencies

**Alternative Standalone Script:**
- `simple_calendar_generator.py` - Standalone version

### Step 3: Install Dependencies
In Replit shell, run:
```bash
pip install flask flask-cors reportlab
```

### Step 4: Configure Replit
Create a `.replit` file:
```toml
run = "python src/main.py"
modules = ["python-3.11"]

[nix]
channel = "stable-22_11"

[deployment]
run = ["sh", "-c", "python src/main.py"]
```

### Step 5: Run the Application
Click "Run" in Replit. The web interface will be available at your Replit URL.

## File Structure

```
calendar-pdf-exporter/
├── src/
│   ├── main.py                 # Flask app entry point
│   ├── generate_calendar.py    # PDF generation logic
│   ├── routes/
│   │   └── calendar.py         # API endpoints
│   ├── static/
│   │   └── index.html          # Web interface
│   └── models/
│       └── user.py             # Database models (optional)
├── requirements.txt            # Dependencies
├── simple_calendar_generator.py # Standalone script
└── README.md                   # This file
```

## Usage

### Web Interface
1. Set the week start date (defaults to current Monday)
2. Add events with:
   - Event title
   - Date
   - Start and end times
   - Optional description
3. Click "Generate PDF for reMarkable Pro"
4. Download the optimized PDF

### Standalone Script
Modify the `events` array in `simple_calendar_generator.py`:
```python
events = [
    {
        "title": "Your Event",
        "date": "2025-09-08",
        "start_time": "09:00",
        "end_time": "10:30",
        "description": "Event description"
    }
]
```

## Key Improvements Over Original

### Fixed Issues:
1. **Time Range**: Now covers 07:00-22:00 (was 09:00-17:00)
2. **Time Format**: Military time throughout
3. **Page Orientation**: Correct landscape/portrait layout
4. **Hyperlinks**: Bidirectional navigation between pages
5. **Event Blocks**: Proportional to duration
6. **reMarkable Optimization**: Perfect dimensions and DPI

### Enhanced Features:
1. **Visual Event Representation**: Color-coded blocks
2. **Professional Typography**: Clean, readable fonts
3. **Grid Layout**: Proper alignment and spacing
4. **Navigation**: Intuitive page linking
5. **Responsive Design**: Works on desktop and mobile

## Technical Specifications

- **Weekly Page**: 2160x1620 pixels (landscape)
- **Daily Pages**: 1620x2160 pixels (portrait)
- **DPI**: 229 PPI (reMarkable Pro native)
- **Time Slots**: 31 half-hour intervals (07:00-22:00)
- **Font**: Helvetica family for optimal e-ink rendering
- **Colors**: High contrast for e-ink display

## Dependencies

```
flask==3.1.1
flask-cors==6.0.0
reportlab==4.4.3
pillow==11.3.0
```

## Troubleshooting

### Common Issues:

1. **Import Error**: Ensure all dependencies are installed
2. **Date Format**: Use YYYY-MM-DD format for dates
3. **Time Format**: Use HH:MM format (24-hour)
4. **PDF Not Generating**: Check file permissions

### Replit-Specific:
1. Make sure Python 3.11 is selected
2. Install dependencies in the Shell tab
3. Use the provided `.replit` configuration

## Support

This solution addresses all the requirements from your original request:
- ✅ 8 pages total (1 weekly + 7 daily)
- ✅ Landscape weekly view
- ✅ Portrait daily views
- ✅ Military time format
- ✅ 07:00-22:00 time range
- ✅ 30-minute intervals
- ✅ Bidirectional hyperlinks
- ✅ reMarkable Pro optimization

The code is complete and ready for use in Replit or as a standalone application.

